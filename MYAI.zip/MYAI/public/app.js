// ── Constants ─────────────────────────────────────────────────────────────────
const MODEL_LABELS = {
  'gemini':    { label: 'Pro'  },
  'groq-fast': { label: 'Fast' },
  'groq-deep': { label: 'Deep' }
};


// ── State ─────────────────────────────────────────────────────────────────────
let userName        = localStorage.getItem('px_name')       || 'Harsh';
let currentModel    = localStorage.getItem('px_model')      || 'gemini';
let apiMode         = localStorage.getItem('px_api_mode')   || 'free';
let apiKey          = localStorage.getItem('px_api_key')    || '';
let geminiKey       = localStorage.getItem('px_gemini_key') || '';
let groqKey         = localStorage.getItem('px_groq_key')   || '';
let webSearchActive = localStorage.getItem('px_web_search') === 'true';
let currentTheme    = localStorage.getItem('px_theme')      || 'dark';
let currentMessages = [];
let currentChatId   = null;
let isTyping        = false;
let sidebarOpen     = true;
let modelPickerOpen = false;

// Chat sessions stored in localStorage as px_chats = { id: { title, messages, ts } }
function loadSessions()  { try { return JSON.parse(localStorage.getItem('px_chats') || '{}'); } catch { return {}; } }
function saveSessions(s) { localStorage.setItem('px_chats', JSON.stringify(s)); }

// ── DOM ───────────────────────────────────────────────────────────────────────
const chatContainer = document.getElementById('chat-container');
const messagesList  = document.getElementById('messages-list');
const welcomeScreen = document.getElementById('welcome-screen');
const chatInput     = document.getElementById('chat-input');
const webSearchBtn  = document.getElementById('web-search-btn');

// ── Init ──────────────────────────────────────────────────────────────────────
document.addEventListener('DOMContentLoaded', () => {
  setupMarked();
  setupInputListeners();
  updateWebSearchBtnUI();
  updateModelUI();
  renderSidebar();
  initParticles();
  applyTheme(currentTheme);
  document.getElementById('welcome-name').textContent = userName;
  chatInput.focus();
  // Close model picker when clicking outside
  document.addEventListener('click', (e) => {
    if (!e.target.closest('#model-trigger-btn') && !e.target.closest('#model-picker')) {
      closeModelPicker();
    }
  });
});

// ── Particles ─────────────────────────────────────────────────────────────────
function initParticles() {
  const canvas = document.getElementById('particle-canvas');
  if (!canvas) return;
  const ctx = canvas.getContext('2d');
  let particles = [], W, H;
  function resize() { W = canvas.width = window.innerWidth; H = canvas.height = window.innerHeight; }
  resize();
  window.addEventListener('resize', resize);
  function mkP() {
    return { x: Math.random()*W, y: Math.random()*H, r: Math.random()*1.0+0.2,
      dx: (Math.random()-0.5)*0.2, dy: -Math.random()*0.3-0.05,
      alpha: Math.random()*0.25+0.03, life: 0, maxLife: Math.random()*350+200 };
  }
  for (let i=0;i<60;i++) particles.push(mkP());
  function draw() {
    ctx.clearRect(0,0,W,H);
    particles.forEach((p,i) => {
      p.x+=p.dx; p.y+=p.dy; p.life++;
      const f = p.life<40 ? p.life/40 : p.life>p.maxLife-40 ? (p.maxLife-p.life)/40 : 1;
      ctx.beginPath(); ctx.arc(p.x,p.y,p.r,0,Math.PI*2);
      // Mix of blue and white particles
      const isBlue = i % 3 !== 0;
      ctx.fillStyle = isBlue
        ? `rgba(80,120,255,${p.alpha*f})`
        : `rgba(200,200,255,${p.alpha*f*0.5})`;
      ctx.fill();
      if (p.life>=p.maxLife||p.y<-10) particles[i]=mkP();
    });
    requestAnimationFrame(draw);
  }
  draw();
}

// ── Marked setup ──────────────────────────────────────────────────────────────
function setupMarked() {
  const renderer = new marked.Renderer();
  renderer.code = function(token, language) {
    let rawCode, lang;
    if (token && typeof token === 'object' && token.text !== undefined) {
      rawCode = token.text; lang = token.lang || language || 'text';
    } else { rawCode = token; lang = language || 'text'; }
    rawCode = (rawCode || '').toString().trim();
    lang = lang && hljs.getLanguage(lang) ? lang : 'text';
    let highlighted;
    try { highlighted = hljs.highlight(rawCode, { language: lang }).value; }
    catch(_) { highlighted = hljs.highlightAuto(rawCode).value; }
    const codeId = 'c-' + Math.random().toString(36).substr(2,8);
    return `<div class="code-block-wrapper"><div class="code-header"><span>${lang.toUpperCase()}</span><button onclick="copyCode('${codeId}')"><i class="fa-regular fa-copy"></i> Copy</button></div><pre><code id="${codeId}" class="hljs language-${lang}">${highlighted}</code></pre></div>`;
  };
  marked.setOptions({ renderer, breaks: true });
}

// ── Sidebar ───────────────────────────────────────────────────────────────────
function toggleSidebar() {
  sidebarOpen = !sidebarOpen;
  const sb = document.getElementById('sidebar');
  const tab = document.getElementById('sidebar-tab');
  if (sidebarOpen) { sb.classList.remove('collapsed'); tab.classList.add('hidden'); }
  else             { sb.classList.add('collapsed');    tab.classList.remove('hidden'); }
}

function renderSidebar() {
  const list = document.getElementById('chat-history-list');
  if (!list) return;
  const sessions = loadSessions();
  const ids = Object.keys(sessions).sort((a,b) => sessions[b].ts - sessions[a].ts);
  if (ids.length === 0) {
    list.innerHTML = '<div style="font-size:11px;color:#222;padding:8px 6px;">No recent chats</div>';
    return;
  }
  list.innerHTML = ids.map(id => {
    const s = sessions[id];
    const isActive = id === currentChatId ? 'active' : '';
    return `<div class="history-item ${isActive}" onclick="loadChat('${id}')">
      <div class="history-checkbox"></div>
      <div class="history-title" title="${esc(s.title)}">${esc(s.title)}</div>
      <div class="history-actions">
        <button class="history-action-btn del" onclick="deleteChat(event,'${id}')" title="Delete">
          <i class="fa-solid fa-trash-can"></i>
        </button>
      </div>
    </div>`;
  }).join('');
}

function loadChat(id) {
  const sessions = loadSessions();
  const session = sessions[id];
  if (!session) return;
  currentChatId = id;
  currentMessages = session.messages || [];
  messagesList.innerHTML = '';
  welcomeScreen.classList.add('hidden');
  currentMessages.forEach(m => {
    if (m.role === 'user') appendUserMsg(m.content);
    else appendAIMsg(m.content, [], true); // instant render (no typing)
  });
  renderSidebar();
}

function deleteChat(e, id) {
  e.stopPropagation();
  const sessions = loadSessions();
  delete sessions[id];
  saveSessions(sessions);
  if (currentChatId === id) startNewChat();
  else renderSidebar();
}

function clearAllChats() {
  if (!confirm('Clear all chat history?')) return;
  localStorage.removeItem('px_chats');
  startNewChat();
}

function saveCurrentChat() {
  if (!currentChatId || currentMessages.length === 0) return;
  const sessions = loadSessions();
  const title = currentMessages.find(m => m.role === 'user')?.content?.slice(0,40) || 'Chat';
  sessions[currentChatId] = { title, messages: currentMessages, ts: Date.now() };
  saveSessions(sessions);
  renderSidebar();
}

// ── Model Picker ──────────────────────────────────────────────────────────────
function toggleModelPicker(e) {
  e.stopPropagation();
  modelPickerOpen ? closeModelPicker() : openModelPicker();
}
function openModelPicker() {
  modelPickerOpen = true;
  document.getElementById('model-picker').classList.remove('hidden');
  document.getElementById('model-trigger-btn').classList.add('open');
  document.getElementById('model-chevron').classList.remove('flipped');
}
function closeModelPicker() {
  modelPickerOpen = false;
  document.getElementById('model-picker').classList.add('hidden');
  document.getElementById('model-trigger-btn').classList.remove('open');
  document.getElementById('model-chevron').classList.add('flipped');
}

function selectModel(model) {
  currentModel = model;
  localStorage.setItem('px_model', model);
  updateModelUI();
  closeModelPicker();
}

function updateModelUI() {
  const info = MODEL_LABELS[currentModel] || MODEL_LABELS['gemini'];
  const labelEl = document.getElementById('model-label');
  if (labelEl) labelEl.textContent = info.label;
  // Update checkmarks
  Object.keys(MODEL_LABELS).forEach(m => {
    const el = document.getElementById('check-' + m);
    if (el) el.innerHTML = m === currentModel ? '<i class="fa-solid fa-check"></i>' : '';
  });
}

// ── Web Search ────────────────────────────────────────────────────────────────
function updateWebSearchBtnUI() {
  if (!webSearchBtn) return;
  if (webSearchActive) {
    webSearchBtn.classList.add('search-btn-active');
    webSearchBtn.title = 'Web Search: ON';
  } else {
    webSearchBtn.classList.remove('search-btn-active');
    webSearchBtn.title = 'Toggle Web Search';
  }
}

// ── Input Listeners ───────────────────────────────────────────────────────────
function setupInputListeners() {
  document.getElementById('chat-form').addEventListener('submit', (e) => { e.preventDefault(); handleSubmit(); });
  chatInput.addEventListener('keydown', (e) => {
    if (e.key === 'Enter' && !e.shiftKey) { e.preventDefault(); handleSubmit(); }
  });
  chatInput.addEventListener('input', function() {
    this.style.height = 'auto';
    this.style.height = Math.min(this.scrollHeight, 160) + 'px';
  });
  if (webSearchBtn) {
    webSearchBtn.addEventListener('click', () => {
      webSearchActive = !webSearchActive;
      localStorage.setItem('px_web_search', webSearchActive);
      updateWebSearchBtnUI();
    });
  }
}

// ── Start New Chat ────────────────────────────────────────────────────────────
function startNewChat() {
  currentMessages = [];
  currentChatId   = 'chat-' + Date.now();
  messagesList.innerHTML = '';
  welcomeScreen.classList.remove('hidden');
  chatInput.value = '';
  chatInput.style.height = 'auto';
  chatInput.focus();
  renderSidebar();
}

// ── Submit ────────────────────────────────────────────────────────────────────
async function handleSubmit() {
  const text = chatInput.value.trim();
  if (!text || isTyping) return;
  chatInput.value = '';
  chatInput.style.height = 'auto';

  if (!currentChatId) currentChatId = 'chat-' + Date.now();
  welcomeScreen.classList.add('hidden');

  currentMessages.push({ role: 'user', content: text });
  appendUserMsg(text);

  // Thinking indicator
  const lid = 'ld-' + Date.now();
  const ld = document.createElement('div');
  ld.id = lid;
  ld.className = 'msg-wrap';
  ld.innerHTML = `
    <div class="ai-avatar">⚡</div>
    <div style="display:flex;align-items:center;gap:8px;padding-top:6px;">
      <span style="font-size:12px;color:#333;font-weight:500;">${webSearchActive ? 'Searching web' : 'Thinking'}</span>
      <span style="display:flex;gap:4px;align-items:center;">
        <span class="thinking-dot"></span>
        <span class="thinking-dot"></span>
        <span class="thinking-dot"></span>
      </span>
    </div>`;
  messagesList.appendChild(ld);
  scrollBottom();

  if (!navigator.onLine) {
    const offlineMsg = '⚠️ No internet connection detected. Please connect to the internet to access Parallax AI models.';
    currentMessages.push({ role: 'assistant', content: offlineMsg });
    await appendAIMsg(offlineMsg, [], true);
    return;
  }

  try {
    const body = { messages: currentMessages, model: currentModel, webSearch: webSearchActive };
    const keys = [];
    if (geminiKey) keys.push(geminiKey);
    if (groqKey)   keys.push(groqKey);
    if (apiKey)    keys.push(apiKey);
    if (keys.length > 0) body.apiKey = keys;

    let reply = '', sources = [], attempts = 0;

    while (attempts < 3) {
      attempts++;
      try {
        const res = await fetch('/api/chat', {
          method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify(body)
        });
        if (!res.ok) {
          let errData = {}; try { errData = await res.json(); } catch(_) {}
          reply = errData.reply || `⚠️ Server error (${res.status}). Please try again.`;
          break;
        }
        const data = await res.json();
        reply = data.reply || ''; sources = data.sources || [];
        if (reply && !reply.includes('temporarily unavailable') && !reply.includes('high demand')) break;
        if (attempts < 3) await new Promise(r => setTimeout(r, 3000));
      } catch (fetchErr) {
        if (!navigator.onLine) {
          reply = '⚠️ No internet connection detected. Unable to connect to Parallax AI models.';
          break;
        }
        if (attempts < 3) await new Promise(r => setTimeout(r, 3000));
        else reply = '⚠️ Network connection issue. Unable to connect to Parallax AI models. Please check your internet connection.';
      }
    }

    if (!reply) reply = '⚠️ Unable to connect to Parallax AI models. Please check your internet connection and try again.';
    document.getElementById(lid)?.remove();
    currentMessages.push({ role: 'assistant', content: reply });
    await appendAIMsg(reply, sources, false);
    saveCurrentChat();

  } catch (err) {
    document.getElementById(lid)?.remove();
    const msg = `⚠️ Something went wrong: ${err.message}`;
    currentMessages.push({ role: 'assistant', content: msg });
    await appendAIMsg(msg, [], true);
  }
}

// ── Append User Message ───────────────────────────────────────────────────────
function appendUserMsg(content) {
  const initial = (userName || 'H').charAt(0).toUpperCase();
  const wrap = document.createElement('div');
  wrap.className = 'msg-wrap user-wrap';
  wrap.innerHTML = `
    <div class="user-bubble">${esc(content)}</div>
    <div class="user-avatar">${initial}</div>`;
  messagesList.appendChild(wrap);
  scrollBottom();
}

// ── Append AI Message ─────────────────────────────────────────────────────────
async function appendAIMsg(content, sources = [], instant = false) {
  isTyping = !instant;

  const wrap = document.createElement('div');
  wrap.className = 'msg-wrap msg-ai-wrap';

  const avatar = document.createElement('div');
  avatar.className = 'ai-avatar';
  avatar.textContent = '⚡';

  const bodyWrap = document.createElement('div');
  bodyWrap.style.flex = '1';
  bodyWrap.style.minWidth = '0';

  const prose = document.createElement('div');
  prose.className = 'prose-chat';

  bodyWrap.appendChild(prose);
  wrap.appendChild(avatar);
  wrap.appendChild(bodyWrap);
  messagesList.appendChild(wrap);
  scrollBottom();

  if (instant) {
    prose.innerHTML = marked.parse(content);
  } else {
    // Word-by-word typing
    const words = content.split(' ');
    let built = '';
    const chunk = 3;
    for (let i = 0; i < words.length; i += chunk) {
      built += (i > 0 ? ' ' : '') + words.slice(i, i + chunk).join(' ');
      prose.innerHTML = marked.parse(built);
      scrollBottom();
      await new Promise(r => setTimeout(r, 16));
    }
    prose.innerHTML = marked.parse(content);
  }

  // Sources
  if (sources && sources.length > 0) {
    const srcBar = document.createElement('div');
    srcBar.className = 'sources-bar';
    srcBar.innerHTML = `
      <div class="sources-label"><i class="fa-solid fa-globe" style="color:#60a5fa;font-size:9px;"></i> Live Sources</div>
      <div style="display:flex;flex-wrap:wrap;gap:6px;">
        ${sources.map(s => `<a href="${esc(s.url)}" target="_blank" rel="noopener" class="source-pill"><i class="fa-solid fa-arrow-up-right-from-square" style="font-size:8px;flex-shrink:0;"></i><span class="source-title">${esc(s.title||s.url)}</span></a>`).join('')}
      </div>`;
    bodyWrap.appendChild(srcBar);
  }

  // Actions
  const actions = document.createElement('div');
  actions.className = 'msg-actions';
  const copyBtn = document.createElement('button');
  copyBtn.className = 'action-btn';
  copyBtn.innerHTML = '<i class="fa-regular fa-copy"></i> Copy';
  copyBtn.onclick = () => {
    navigator.clipboard.writeText(content).then(() => {
      copyBtn.innerHTML = '<i class="fa-solid fa-check" style="color:#4ade80"></i> Copied';
      setTimeout(() => { copyBtn.innerHTML = '<i class="fa-regular fa-copy"></i> Copy'; }, 1800);
    });
  };
  const likeBtn = document.createElement('button');
  likeBtn.className = 'action-btn';
  likeBtn.innerHTML = '<i class="fa-regular fa-thumbs-up"></i>';
  likeBtn.onclick = () => { likeBtn.innerHTML = likeBtn.innerHTML.includes('fa-regular') ? '<i class="fa-solid fa-thumbs-up" style="color:#4ade80"></i>' : '<i class="fa-regular fa-thumbs-up"></i>'; };
  const dislikeBtn = document.createElement('button');
  dislikeBtn.className = 'action-btn';
  dislikeBtn.innerHTML = '<i class="fa-regular fa-thumbs-down"></i>';
  dislikeBtn.onclick = () => { dislikeBtn.innerHTML = dislikeBtn.innerHTML.includes('fa-regular') ? '<i class="fa-solid fa-thumbs-down" style="color:#f87171"></i>' : '<i class="fa-regular fa-thumbs-down"></i>'; };
  actions.append(copyBtn, likeBtn, dislikeBtn);
  bodyWrap.appendChild(actions);
  scrollBottom();
  isTyping = false;
}

// ── Themes ────────────────────────────────────────────────────────────────────
function setTheme(theme) {
  currentTheme = theme;
  localStorage.setItem('px_theme', theme);
  applyTheme(theme);
}

function applyTheme(theme) {
  const root = document.getElementById('html-root');
  if (root) root.setAttribute('data-theme', theme);
  // Update active button
  ['dark', 'mix', 'light'].forEach(t => {
    const btn = document.getElementById('theme-' + t);
    if (btn) btn.classList.toggle('active', t === theme);
  });
}

// ── Helpers ───────────────────────────────────────────────────────────────────
function sendQuickPrompt(text) { chatInput.value = text; handleSubmit(); }
function scrollBottom()        { chatContainer.scrollTop = chatContainer.scrollHeight; }
function copyCode(id)          { const el = document.getElementById(id); if (el) navigator.clipboard.writeText(el.innerText); }
function toggleFullscreen()    { if (!document.fullscreenElement) document.documentElement.requestFullscreen().catch(()=>{}); else document.exitFullscreen(); }

let lightsOn = localStorage.getItem('px_lights') !== 'off';
function toggleLights() {
  lightsOn = !lightsOn;
  localStorage.setItem('px_lights', lightsOn ? 'on' : 'off');
  const el  = document.getElementById('live-lights');
  const btn = document.getElementById('lights-toggle-btn');
  if (el)  el.classList.toggle('off', !lightsOn);
  if (btn) btn.innerHTML = `<i class="fa-solid fa-wand-magic-sparkles"></i> Lights: ${lightsOn ? 'On' : 'Off'}`;
}
// Apply saved lights state on load
document.addEventListener('DOMContentLoaded', () => {
  if (!lightsOn) {
    const el = document.getElementById('live-lights');
    if (el) el.classList.add('off');
    const btn = document.getElementById('lights-toggle-btn');
    if (btn) btn.innerHTML = '<i class="fa-solid fa-wand-magic-sparkles"></i> Lights: Off';
  }
});

function esc(s) { return s ? s.replace(/&/g,'&amp;').replace(/</g,'&lt;').replace(/>/g,'&gt;').replace(/"/g,'&quot;').replace(/'/g,'&#039;') : ''; }

// ── Settings ──────────────────────────────────────────────────────────────────
function openSettingsModal() {
  document.getElementById('settings-modal').classList.remove('hidden');
  const n = document.getElementById('setting-name');    if (n) n.value = userName === 'Harsh' ? '' : userName;
  const g = document.getElementById('setting-gemini-key'); if (g && geminiKey) g.value = geminiKey;
  const gr = document.getElementById('setting-groq-key');  if (gr && groqKey)  gr.value = groqKey;
  renderApiModeUI();
}
function closeSettingsModal() { document.getElementById('settings-modal').classList.add('hidden'); }

function setApiMode(mode) {
  apiMode = mode; localStorage.setItem('px_api_mode', mode); renderApiModeUI();
}
function renderApiModeUI() {
  const fb = document.getElementById('mode-free-btn');
  const ab = document.getElementById('mode-api-btn');
  const ks = document.getElementById('api-key-section');
  if (apiMode === 'free') { fb?.classList.add('active'); ab?.classList.remove('active'); ks?.classList.add('hidden'); }
  else { ab?.classList.add('active'); fb?.classList.remove('active'); ks?.classList.remove('hidden'); }
}
function saveSettings() {
  const n = document.getElementById('setting-name')?.value.trim();
  if (n) { userName = n; localStorage.setItem('px_name', n); }
  const gEl  = document.getElementById('setting-gemini-key');
  const grEl = document.getElementById('setting-groq-key');
  if (gEl)  { geminiKey = gEl.value.trim(); if (geminiKey) localStorage.setItem('px_gemini_key', geminiKey); }
  if (grEl) { groqKey   = grEl.value.trim(); if (groqKey)   localStorage.setItem('px_groq_key',   groqKey); }
  localStorage.setItem('px_api_mode', apiMode);
  // Update welcome name
  const wn = document.getElementById('welcome-name');
  if (wn) wn.textContent = userName;
  closeSettingsModal();
}
