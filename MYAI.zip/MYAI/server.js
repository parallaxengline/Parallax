const express = require('express');
const cors = require('cors');
const path = require('path');
const axios = require('axios');
require('dotenv').config();

const app = express();
const PORT = process.env.PORT || 3000;

app.use(cors());
app.use(express.json({ limit: '10mb' }));
app.use(express.static(path.join(__dirname, 'public')));

// Available Models shown in UI
const PARALLAX_MODELS = [
  { id: 'gemini', name: 'Parallax Pro' },
  { id: 'groq-fast', name: 'Parallax Flash' },
  { id: 'groq-deep', name: 'Parallax Deep' },
  { id: 'auto', name: 'Parallax Code' }
];
app.get('/api/models', (_req, res) => res.json(PARALLAX_MODELS));

// ─── Question Type Detectors ─────────────────────────────────────────────────

function isCreatorQuestion(text) {
  const q = (text || '').toLowerCase();
  return [
    'who made you', 'who created you', 'who built you', 'who developed you',
    'who is your creator', 'who designed you', 'who programmed you', 'who owns you',
    'who made parallax', 'who created parallax', 'tell me about your creator',
    'who coded you', 'your developer', 'your creator',
    'who are you', 'what are you', 'who is this', 'what is this',
    'are you chatgpt', 'are you gpt', 'are you gemini', 'are you claude',
    'are you openai', 'are you made by', 'which ai are you', 'which model are you',
    'what model are you', 'which ai model', 'what ai model', 'based on which model',
    'built on which model', 'which llm', 'what llm', 'how were you made',
    'how are you made', 'how were you built', 'how were you created',
    'what is your model', 'underlying model', 'which company made you',
    'tell me about yourself', 'introduce yourself', 'what can you do'
  ].some(p => q.includes(p));
}

function isDateQuestion(text) {
  const q = (text || '').toLowerCase().replace(/[?!.,]/g, '');
  return (
    (q.includes('date') && (q.includes('what') || q.includes('today') || q.includes('current') || q.includes('now') || q.includes('tell'))) ||
    q.includes("today's date") || q.includes("todays date") || q.trim() === 'date'
  );
}

function isTimeQuestion(text) {
  const q = (text || '').toLowerCase().replace(/[?!.,]/g, '');
  return (
    (q.includes('time') && (q.includes('what') || q.includes('current') || q.includes('now') || q.includes('tell') || q.includes('is'))) ||
    q.trim() === 'time'
  );
}

function isWebSearchNeeded(text) {
  if (!text) return false;
  if (isDateQuestion(text) || isTimeQuestion(text)) return false;
  const q = text.toLowerCase();
  return [
    'latest', 'today', 'current', 'currently', 'right now', 'recent', 'recently', 'new',
    'news', 'headline', 'weather', 'price', 'price of', 'stock', 'bitcoin', 'crypto',
    'score', 'winner', 'who won', 'upcoming', 'release date', 'schedule', 'fixtures',
    'what happened', 'search', 'google this', 'browse', '2024', '2025', '2026', '2027',
    'president of', 'prime minister', 'ceo of', 'just happened', 'this week', 'this month',
    'where is', 'when is', 'how much is', 'event', 'trending', 'update', 'status'
  ].some(t => q.includes(t));
}

function unescapeHTML(str) {
  return (str || '')
    .replace(/&quot;/g, '"').replace(/&#x27;/g, "'").replace(/&#39;/g, "'")
    .replace(/&amp;/g, '&').replace(/&lt;/g, '<').replace(/&gt;/g, '>').replace(/&nbsp;/g, ' ').trim();
}

// ─── Web Search via DuckDuckGo Lite ─────────────────────────────────────────

async function searchWeb(query) {
  try {
    const q = (query || '').replace(/^(search|google|look up|find|search for)\s+/i, '').trim();
    const res = await axios.post(
      'https://lite.duckduckgo.com/lite/',
      `q=${encodeURIComponent(q)}`,
      {
        headers: {
          'Content-Type': 'application/x-www-form-urlencoded',
          'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64)'
        },
        timeout: 8000
      }
    );
    const html = res.data || '';
    const links = [...html.matchAll(/<a[^>]+class=['"]result-link['"][^>]*>([\s\S]*?)<\/a>/gi)];
    const snips = [...html.matchAll(/<td[^>]+class=['"]result-snippet['"][^>]*>([\s\S]*?)<\/td>/gi)];
    const results = [];
    for (let i = 0; i < Math.min(links.length, snips.length, 4); i++) {
      const fullA = links[i][0];
      const title = unescapeHTML(links[i][1].replace(/<[^>]+>/g, '').trim());
      const href = (fullA.match(/href=['"]([^'"]+)['"]/i) || [])[1] || '';
      const snippet = unescapeHTML(snips[i][1].replace(/<[^>]+>/g, '').trim());
      if (title && snippet) results.push({ title, url: href, snippet });
    }
    return results;
  } catch (e) {
    console.warn('[Search] DuckDuckGo failed:', e.message);
    return [];
  }
}

function extractText(data) {
  if (!data) return '';
  if (typeof data === 'string') {
    const t = data.trim();
    return t.length > 2 ? t : '';
  }
  const t =
    data?.choices?.[0]?.message?.content ||
    data?.choices?.[0]?.text ||
    data?.content ||
    data?.text ||
    data?.output ||
    (typeof data?.message === 'string' ? data.message : data?.message?.content) ||
    '';
  return typeof t === 'string' ? t.trim() : '';
}

// ─── Gemini API Helper (builds body from messages) ───────────────────────────

function buildGeminiBody(messages) {
  const contents = messages
    .filter(m => m.role !== 'system')
    .map(m => ({ role: m.role === 'assistant' ? 'model' : 'user', parts: [{ text: m.content }] }));
  const systemInstruction = messages.find(m => m.role === 'system')?.content;
  const body = { contents };
  if (systemInstruction) {
    body.systemInstruction = { parts: [{ text: systemInstruction }] };
  }
  return { contents, body };
}

// ─── 1. Google Gemini API Caller ─────────────────────────────────────────────

async function callGemini(messages, apiKey) {
  if (!apiKey) return '';
  const GEMINI_MODEL = 'gemini-3.8-flash';
  const url = `https://generativelanguage.googleapis.com/v1beta/models/${GEMINI_MODEL}:generateContent?key=${apiKey.trim()}`;

  const makeRequest = async () => {
    const { contents, body } = buildGeminiBody(messages);
    if (!contents.length) return '';
    const res = await axios.post(url, body, {
      headers: { 'Content-Type': 'application/json' },
      timeout: 30000
    });
    return res.data?.candidates?.[0]?.content?.parts?.[0]?.text?.trim() || '';
  };

  try {
    return await makeRequest();
  } catch (err) {
    const status = err.response?.status;
    const msg = err.response?.data?.error?.message || err.message;
    console.warn(`[Gemini] Call failed: ${status} ${msg}`);

    // Retry once on 503 (high demand) or timeout
    if (status === 503 || err.code === 'ECONNABORTED') {
      console.warn('[Gemini] Retrying after 1.5s...');
      await new Promise(r => setTimeout(r, 1500));
      try {
        return await makeRequest();
      } catch (err2) {
        console.warn('[Gemini] Retry also failed:', err2.response?.status, err2.message);
      }
    }
    return '';
  }
}

// ─── 2. Groq Cloud API Caller ────────────────────────────────────────────────

async function callGroq(messages, apiKey, model) {
  if (!apiKey) return '';
  try {
    const res = await axios.post(
      'https://api.groq.com/openai/v1/chat/completions',
      { model, messages, max_tokens: 4096, temperature: 0.7 },
      {
        headers: {
          Authorization: `Bearer ${apiKey.trim()}`,
          'Content-Type': 'application/json'
        },
        timeout: 30000
      }
    );
    return extractText(res.data);
  } catch (err) {
    const status = err.response?.status;
    const msg = err.response?.data?.error?.message || err.message;
    console.warn(`[Groq ${model}] Call failed: ${status} ${msg}`);
    return '';
  }
}

// ─── Main AI Query Pipeline ──────────────────────────────────────────────────

async function queryAI(messages, model, userSystemPrompt, apiKey, webSearch) {
  const lastMsg = [...messages].reverse().find(m => m.role === 'user')?.content || '';

  // ── Instant answers (no API needed) ──────────────────────────────────────

  if (isDateQuestion(lastMsg)) {
    const d = new Date().toLocaleDateString('en-US', { weekday: 'long', year: 'numeric', month: 'long', day: 'numeric' });
    return { reply: `Today's date is **${d}**.`, sources: [] };
  }

  if (isTimeQuestion(lastMsg)) {
    const t = new Date().toLocaleTimeString('en-US', { hour: '2-digit', minute: '2-digit', timeZoneName: 'short' });
    return { reply: `The current time is **${t}**.`, sources: [] };
  }

  if (isCreatorQuestion(lastMsg)) {
    return {
      reply: `I am **Parallax**, an advanced AI assistant created and built from scratch by **Harsh Verma**. 🚀\n\nI can help you with:\n- 💻 **Coding** – write complete, working code with explanations\n- 🧮 **Math & Science** – solve equations, explain concepts\n- ✍️ **Writing** – essays, emails, stories\n- 🔍 **Research** – real-time web search\n- 🧠 **Analysis** – data, logic, reasoning\n\nHow can I assist you today?`,
      sources: []
    };
  }

  // ── Web search (if needed) ────────────────────────────────────────────────

  let searchResults = [];
  const shouldSearch = webSearch === true || (webSearch !== false && isWebSearchNeeded(lastMsg));
  if (shouldSearch) {
    try {
      searchResults = await searchWeb(lastMsg);
      console.log(`[WebSearch] Found ${searchResults.length} results for: "${lastMsg.slice(0, 50)}"`);
    } catch (e) { /* ignore */ }
  }

  // ── Build system prompt ───────────────────────────────────────────────────

  const today = new Date().toDateString();
  const base = userSystemPrompt ||
    `You are Parallax, a highly capable AI assistant created by Harsh Verma. ` +
    `You excel at coding (write complete, clean, working code with step-by-step explanations), ` +
    `mathematics, science, writing, and analysis. ` +
    `IMPORTANT: Always write full working code. Never say you cannot write code. ` +
    `Format all responses in clean markdown with proper syntax highlighting. Current date: ${today}.`;

  let searchCtx = '';
  if (searchResults.length > 0) {
    searchCtx = '\n\nREAL-TIME WEB DATA:\n' +
      searchResults.slice(0, 3).map((r, i) => `[${i + 1}] ${r.title}: ${r.snippet.slice(0, 150)}`).join('\n');
  }

  const sysMsg = base + searchCtx;
  const conversation = [{ role: 'system', content: sysMsg }, ...messages.slice(-10)];

  // ── Resolve API keys ──────────────────────────────────────────────────────

  let keyList = [];
  if (Array.isArray(apiKey)) keyList = [...apiKey];
  else if (typeof apiKey === 'string' && apiKey.trim()) keyList = [apiKey.trim()];

  const userGeminiKey = keyList.find(k => typeof k === 'string' && (k.startsWith('AIza') || k.startsWith('AQ.')));
  const userGroqKey = keyList.find(k => typeof k === 'string' && k.startsWith('gsk_'));

  const geminiKey = userGeminiKey || process.env.GEMINI_API_KEY || null;
  const groqKey = userGroqKey || process.env.GROQ_API_KEY || null;

  console.log(`[Parallax] Keys available – Gemini: ${geminiKey ? '✓' : '✗'}, Groq: ${groqKey ? '✓' : '✗'}`);

  // ── Step 1: Gemini (primary) ──────────────────────────────────────────────

  if (geminiKey) {
    console.log('[Parallax] Step 1: Trying Gemini (gemini-2.0-flash)...');
    const text = await callGemini(conversation, geminiKey);
    if (text) { console.log('[Parallax] ✓ Gemini responded.'); return { reply: text, sources: searchResults }; }
    console.log('[Parallax] Gemini failed, moving to Groq...');
  } else {
    console.log('[Parallax] No Gemini key – skipping to Groq.');
  }

  // ── Step 2: Groq – openai/gpt-oss-120b (confirmed available) ────────────────

  if (groqKey) {
    console.log('[Parallax] Step 2: Trying Groq (openai/gpt-oss-120b)...');
    const text = await callGroq(conversation, groqKey, 'openai/gpt-oss-120b');
    if (text) { console.log('[Parallax] ✓ Groq gpt-oss-120b responded.'); return { reply: text, sources: searchResults }; }
    console.log('[Parallax] gpt-oss-120b failed, trying next Groq model...');
  }

  // ── Step 3: Groq – openai/gpt-oss-20b (confirmed available) ─────────────────

  if (groqKey) {
    console.log('[Parallax] Step 3: Trying Groq (openai/gpt-oss-20b)...');
    const text = await callGroq(conversation, groqKey, 'openai/gpt-oss-20b');
    if (text) { console.log('[Parallax] ✓ Groq gpt-oss-20b responded.'); return { reply: text, sources: searchResults }; }
    console.log('[Parallax] gpt-oss-20b failed, trying next...');
  }

  // ── Step 4: Groq – qwen/qwen3.8-27b (confirmed available) ───────────────────

  if (groqKey) {
    console.log('[Parallax] Step 4: Trying Groq (qwen/qwen3.8-27b)...');
    const text = await callGroq(conversation, groqKey, 'qwen/qwen3.8-27b');
    if (text) { console.log('[Parallax] ✓ Groq Qwen responded.'); return { reply: text, sources: searchResults }; }
    console.log('[Parallax] Qwen failed, retrying Gemini...');
  }

  // ── Step 5: Gemini retry (after delay) ───────────────────────────────────

  if (geminiKey) {
    console.log('[Parallax] Step 5: Retrying Gemini after 2s pause...');
    await new Promise(r => setTimeout(r, 2000));
    const text = await callGemini(conversation, geminiKey);
    if (text) { console.log('[Parallax] ✓ Gemini retry worked.'); return { reply: text, sources: searchResults }; }
  }

  // ── Step 6: Use web search results if available ───────────────────────────

  if (searchResults.length > 0) {
    console.log('[Parallax] Step 6: Returning web search results as fallback.');
    const summary = searchResults.map(s => `• **[${s.title}](${s.url})**\n  ${s.snippet}`).join('\n\n');
    return {
      reply: `All AI models are currently busy. Here's what I found from a live web search:\n\n${summary}`,
      sources: searchResults
    };
  }

  // ── Step 7: Emergency web search ─────────────────────────────────────────

  try {
    console.log('[Parallax] Step 7: Emergency web search...');
    const liveResults = await searchWeb(lastMsg);
    if (liveResults.length > 0) {
      const summary = liveResults.map(s => `• **[${s.title}](${s.url})**\n  ${s.snippet}`).join('\n\n');
      return {
        reply: `Here's what I found from a live web search:\n\n${summary}`,
        sources: liveResults
      };
    }
  } catch (e) { /* ignore */ }

  // ── Final fallback ────────────────────────────────────────────────────────

  return {
    reply: `⚠️ Unable to connect to Parallax AI models. Please check your internet connection and try again.\n\n` +
      `• Make sure you have an active network connection.\n` +
      `• The servers might be temporarily experiencing high traffic, so you can try again in a moment.`,
    sources: []
  };
}

// ─── Chat endpoint ────────────────────────────────────────────────────────────

app.post('/api/chat', async (req, res) => {
  try {
    const { messages, model = 'gemini', systemPrompt, apiKey, webSearch } = req.body;
    if (!messages || !Array.isArray(messages) || !messages.length) {
      return res.status(400).json({ error: 'Messages array required.' });
    }
    const result = await queryAI(messages, model, systemPrompt, apiKey, webSearch);
    res.json(result);
  } catch (err) {
    console.error('[Chat] Unexpected error:', err);
    res.status(500).json({
      reply: `⚠️ Server error: ${err.message || 'Unknown error'}. Please try again.`,
      sources: []
    });
  }
});

app.listen(PORT, () => {
  console.log(`⚡ Parallax AI running on http://localhost:${PORT}`);
  console.log(`   Gemini key loaded: ${process.env.GEMINI_API_KEY ? '✓' : '✗ (add GEMINI_API_KEY to .env)'}`);
  console.log(`   Groq key loaded:   ${process.env.GROQ_API_KEY ? '✓' : '✗ (add GROQ_API_KEY to .env)'}`);
});
