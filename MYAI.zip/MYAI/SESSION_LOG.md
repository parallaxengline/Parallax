# Parallax AI – Development Session Log
**Project:** `C:\Users\ms365\OneDrive\Desktop\MYAI`
**Last Updated:** 2026-10-07 (Session 3)

> Share this file at the start of any new session so the AI instantly knows everything.

---

## How to Start

```powershell
cd C:\Users\ms365\OneDrive\Desktop\MYAI
Stop-Process -Name node -Force -ErrorAction SilentlyContinue
node server.js
# → ⚡ Parallax AI running on http://localhost:3000
```
Open: **http://localhost:3000** · Press **Ctrl+Shift+R** to hard-refresh after changes.

---

## Architecture

```
Sidebar (chat history)   Main chat area
  ↕ localStorage            ↕
     public/app.js  ──────►  server.js  (Express, port 3000)
                               ├─ instant: date, time, who-are-you
                               ├─ web search: DuckDuckGo Lite
                               └─ AI pipeline:
                                    1. Gemini 3.8 Flash   ← primary
                                    2. Groq gpt-oss-120b  ← fallback 1
                                    3. Groq gpt-oss-20b   ← fallback 2
                                    4. Groq qwen3.8-27b   ← fallback 3
                                    5. Gemini retry       ← fallback 4
                                    6. Web search results ← last resort
```

## Key Files
| File | Purpose |
|------|---------|
| `server.js` | Backend, AI pipeline, all model logic |
| `public/app.js` | Frontend, chat history, model picker, particles |
| `public/index.html` | HTML structure |
| `public/style.css` | Premium CSS: aurora, sidebar, model picker |
| `.env` | API keys |
| `SESSION_LOG.md` | This file |

## API Keys (`.env`)
```
GROQ_API_KEY=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
GEMINI_API_KEY=AQ.Ab8RN6K0acWwqqGJjzcs6H1RsdYM6tjReJlhBIwsTkNfJ_UpLg
```

## Groq Models Available (verified)
```
openai/gpt-oss-120b  ✓ used
openai/gpt-oss-20b   ✓ used
qwen/qwen3.8-27b     ✓ used
```
Dead models (DO NOT USE): llama-3.3-70b, llama-3.1-8b, mixtral-8x7b

---

## Model Names (UI display)
| Internal ID | Label | Display Name |
|---|---|---|
| `gemini` | Normal | Parallax Pro – Gemini 3.8 Flash |
| `groq-fast` | Fast | Parallax Flash – GPT-OSS 120B |
| `groq-deep` | PRO | Parallax Deep – Qwen 27B |

---

## All Bugs Fixed (Sessions 1–3)

1. **Generic "unexpected error"** → Gemini key missing from .env + wrong model names + Groq models all 404 → Fixed all three
2. **"Who are you" said ChatGPT** → `isCreatorQuestion()` didn't include "who are you" → Expanded phrase list (20+ phrases including "which model", "how were you made", "which llm")
3. **code.trim is not a function** → marked.js passes token object not string → Fixed renderer
4. **Port EADDRINUSE** → Already running → `Stop-Process -Name node -Force` first
5. **Groq models wrong** → Fetched real model list via API, updated to correct ones
6. **Blue aurora missing** → Added CSS aurora with blue/purple gradients + particle canvas
7. **No chat history** → Added localStorage-based session persistence with sidebar
8. **Model selector** → Changed from HTML select to popup like reference screenshot
9. **System instructions in settings** → Removed (session 3)
10. **"Parallax AI by Harsh Verma" in title** → Changed to just "Parallax AI"
11. **Disclaimer not visible** → Made it 11px, lighter color, with shield icon

---

## Current UI Features (Session 3)
- **Left sidebar**: Chat history list, New Chat button, Clear All, Settings, Fullscreen
- **Chat history**: Saved in `localStorage` under `px_chats`, survives page refresh/restart
- **Blue aurora**: Animated blue+purple gradient background with floating particle canvas
- **Model picker popup**: Clicking "Normal ▲" shows floating card with Fast/Normal/PRO options and checkmark on selected
- **Typing effect**: AI responses appear word-by-word (like streaming)
- **Hero rings**: 3 rotating orbital rings around ⚡ icon on welcome screen
- **Disclaimer**: "Parallax may make mistakes — always verify critical information."

---

## Current Status ✅
- ✅ Coding, math, writing — all work
- ✅ "Who are you / which model / how were you made" → Parallax/Harsh identity
- ✅ Chat history persists in localStorage (no login required)
- ✅ Blue aurora + particles live background
- ✅ Model picker popup with Parallax names
- ✅ Sidebar toggle (collapse/expand)
- ✅ Fullscreen button
- ✅ Web search auto-triggers + toggle
- ✅ API keys in .env (survive restarts)
- ✅ Word-by-word typing effect on responses
- ✅ No-internet and offline error handling masks API usage completely (Session 4)

---

## Changes Made (Session 4 – 2026-10-09)
### 13. Concealed API Usage & Added Internet Connection Detection
- **Issue:** Error messages previously mentioned "Check your API keys", exposing that backend APIs were being called.
- **Fix in `server.js`:** Updated the fallback error to state:
  > *"⚠️ Unable to connect to Parallax AI models. Please check your internet connection and try again."*
- **Fix in `public/app.js`:** Added active browser connectivity detection using `navigator.onLine` and replaced generic fetch/server errors with:
  > *"⚠️ No internet connection detected. Please connect to the internet to access Parallax AI models."*
- Completely hides all mentions of API keys, providers, and backend implementation from the user during network issues.
