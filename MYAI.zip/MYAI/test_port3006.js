process.env.PORT = '3006';
const app = require('./server.js');
const axios = require('axios');

setTimeout(async () => {
  try {
    console.log('--- TEST 1: now what is the date ---');
    const r1 = await axios.post('http://localhost:3006/api/chat', {
      messages: [{ role: 'user', content: 'now what is the date' }]
    });
    console.log('Date Reply:', r1.data.reply);

    console.log('\n--- TEST 2: who won the FIFA world cup in 2026 ---');
    const r2 = await axios.post('http://localhost:3006/api/chat', {
      messages: [{ role: 'user', content: 'who won the FIFA world cup in 2026' }]
    });
    console.log('World Cup Reply:', r2.data.reply);
    console.log('Sources count:', r2.data.sources?.length);
    process.exit(0);
  } catch(e) {
    console.error('Error:', e.message, e.response?.data);
    process.exit(1);
  }
}, 1000);
